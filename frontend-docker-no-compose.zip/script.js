function showStatus(){
  const el = document.getElementById('status');
  const txt = document.getElementById('statusText');
  el.classList.remove('hidden');
  txt.textContent = 'Site is running — served from static files inside Docker/nginx.';
}
(function(){
  const p = document.querySelector('.tag');
  const t = new Date().toLocaleString();
  p.textContent += ' · built: ' + t;
})();
