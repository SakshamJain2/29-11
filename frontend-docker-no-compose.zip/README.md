# Sample Frontend (Docker-ready) — no docker-compose

This repository contains a minimal static frontend (HTML/CSS/JS) and a `Dockerfile` to build and serve it using `nginx`.

## Files
- `index.html`, `styles.css`, `script.js` — static site
- `Dockerfile` — builds an nginx image that serves the site
- `README.md` — this file

## Build & Run

**Using Docker (build + run):**
```bash
docker build -t sample-frontend:latest .
docker run --rm -p 8080:80 sample-frontend:latest
```

Then open http://localhost:8080

## Notes & Next steps
- Replace the static files with a React/Vue build output if you prefer SPA frameworks.
- If deploying to production consider adding a small nginx config, gzip, and proper caching headers.
